# JB Hi-Fi Australian Retail: FP&A Forecast, Budget vs Actual and Store Business Case

Independent FP&A portfolio project by **Shivam Saxena** (Sydney), built from JB Hi-Fi Limited's (ASX: JBH) public FY24–FY26 results.

**Live dashboard:** https://YOUR-USERNAME.github.io/jb-hifi-fpa-model/
**Excel model:** [`model/JB_HiFi_FPA_Model.xlsx`](model/JB_HiFi_FPA_Model.xlsx)

## Questions answered

1. **Forecast:** Where is EBIT heading for FY27–FY29 under base, bull and bear trading?
2. **Budget vs actual:** Why did FY26 EBIT land where it did against budget?
3. **Business case:** Does opening 5 additional JB Hi-Fi Australia stores create value?

## Key results

| Area | Result |
|---|---|
| FY26 reported (JB Hi-Fi Australia + The Good Guys) | Sales $10,358m, EBIT $731.3m (7.1% margin) |
| FY29 EBIT forecast | Base $814.9m, bull $893.0m, bear $710.3m |
| Sales CAGR FY26–FY29 (base) | 3.9% |
| FY26 EBIT vs illustrative budget | -$13.0m (-1.7%): sales volume -$17.0m, gross margin rate +$4.2m, CODB rate -$5.3m, D&A +$5.1m |
| 5-store business case | $19.0m investment, NPV $36.1m at 9% WACC, IRR 49.5%, payback 2.1 years |
| Downside test | NPV stays positive with new-store sales 30% below plan at an 11% WACC |

## Method

- **Driver-based forecast:** sales = sales per average store x average stores. Sales per store grows with comparable growth; store numbers follow announced openings. Gross margin and CODB move in basis points by scenario; D&A is held at its FY26 share of sales.
- **Scenarios:** base, bull and bear assumptions on comparable growth, store openings, gross margin and CODB, switched from one cell (`Inputs!C3`). Base case reflects soft July FY27 trading (comps -1.4% at JB Hi-Fi Australia, -1.7% at The Good Guys).
- **Budget vs actual:** an illustrative FY26 budget built from FY25 actuals, compared with reported FY26 results. The EBIT bridge splits the variance into volume, gross margin rate, CODB rate and D&A, and reconciles exactly.
- **Business case:** 7-year discounted cash flow for 5 stores with fit-out capex, working capital, pre-opening costs, ramp-up, cannibalisation and tax. Outputs NPV, IRR, payback and an NPV sensitivity grid.
- **Checks:** reported FY24–FY26 EBIT reconciles to the model, the bridge reconciles to actual EBIT, and the sensitivity base case matches the NPV.

## Repository contents

| Path | What it is |
|---|---|
| `model/JB_HiFi_FPA_Model.xlsx` | Full Excel model: Cover, Dashboard, Inputs, Forecast, Budget_vs_Actual, Business_Case, Data_PowerBI |
| `docs/index.html` | Interactive dashboard (published with GitHub Pages) |
| `data/*.csv` | Model outputs used by the dashboard, ready for Power BI or Excel |

## Tools

Excel (driver-based modelling, scenario analysis, DCF), Power BI-ready data model, HTML/JavaScript (D3) dashboard.

## Sources

- JB Hi-Fi Limited, FY26 Results announcement (17 Aug 2026): https://assets.ctfassets.net/xa93kvziwaye/4lDiO6pXReSpSZrNa0uJ7x/c9ed3a070c0aca69702aebbf7c302622/2026_Full_Year_Results.pdf
- JB Hi-Fi Annual Report 2025: https://assets.ctfassets.net/xa93kvziwaye/5dauUDmDVhYZStrgkcQ0fy/ab52796cb86bf9de9dd37503d9c6e29a/12_Sep_2025_Annual_Report_2025_%C3%A2___with_Chairman%C3%A2__s___CEO%C3%A2__s_Report.pdf
- JB Hi-Fi FY25 results announcement (ASX, 11 Aug 2025): https://announcements.asx.com.au/asxpdf/20250811/pdf/06mqqvyn6djfkt.pdf
- Investing.com, FY26 results presentation summary: https://www.investing.com/news/company-news/jb-hifi-fy26-slides-record-sales-overshadowed-by-weak-july-trading-93CH-4862073
- Market Index, FY26 results and July FY27 trading: https://www.marketindex.com.au/news/jb-hi-fi-hits-record-fy26-sales-but-q4-slowdown-sinks-the-stock

## Disclaimer

Built from public information for skills demonstration only. Not affiliated with or endorsed by JB Hi-Fi. The FY26 budget, forecast scenarios and business case inputs are the author's assumptions, not company guidance. Not investment advice.
